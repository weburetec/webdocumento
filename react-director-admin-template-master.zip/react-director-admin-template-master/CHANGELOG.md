# v0.10.0 (WIP)
- migration to `webpack 4`
- migration to `babel 7`
- add prettier
- replace SASS style with styled-components?

# v0.9.0
- ️️⚠️ `node 8 MAX` *compatible* (upper node version will not work since current sass loader is limited)