### Version
0.9.0

### Platform
macOS | windows | linux

### OS version

macOS 10.14.x | windows 10 (patch XXX) | linux Ubuntu 18.x

### Steps to reproduce
1.
2.
3.

### Expected behavior
What should happen

### Actual behavior
What is happening
