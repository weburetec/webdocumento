// react-highlight mock component because jest can't handles finDOMNode
import React from 'react';

export const highlight = () => (
  <p>
    mock react-highlight
  </p>
);
